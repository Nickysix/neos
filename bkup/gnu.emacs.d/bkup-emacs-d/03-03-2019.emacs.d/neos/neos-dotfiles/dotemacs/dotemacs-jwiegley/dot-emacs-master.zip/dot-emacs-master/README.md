# dot-emacs

My .emacs.el file and other personal Emacs goodies

NOTE: I no longer use git-subtree and submodules to track dependencies.
Instead, everything is built and managed using Nix and Nix overlays:
https://github.com/jwiegley/nix-config/blob/master/overlays/10-emacs.nix
