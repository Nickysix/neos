emacs-edg
=========

Emacs Lisp support for working on EDG source code