#!/bin/sh

# generate the configure script

autoconf
